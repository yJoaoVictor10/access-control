export default function Error(){
    return(
        <div>
            <h1>Erro</h1>
        </div>
    )
}