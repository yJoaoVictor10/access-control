export type TipoUsuario = {
  id: number;
  nome: string;
  nomeUsuario: string;
  email: string;
};
